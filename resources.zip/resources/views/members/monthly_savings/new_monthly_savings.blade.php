@extends('master')

@section('body')
<!-- Page-Title -->
@if($member)
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4 class="page-title m-0">Savings</h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card m-b-30">
            <div class="card-body">

            @if($member->savings_locked)

            <p>To proceed, process pending transactions for this member.</p>

            @else

                <a href="{{route('members.dashboard', $member->ippis)}}" class="btn btn-primary waves-effect waves-light"><i class="mdi mdi-backspace-outline"></i> Dashboard</a>
                <a href="{{route('members.savings', $member->ippis)}}" class="btn btn-info waves-effect waves-light"><i class="mdi mdi-file-document-box"></i> Savings</a>

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="mt-4">
                <h5>Add Savings</h5>
                {!! Form::open(['route' => ['members.postNewSavings', $member->ippis]]) !!}

                    {!! Form::hidden('ippis', $member->ippis) !!}

                    <div class="form-group row"><label for="deposit_date" class="col-sm-3 col-form-label">Date</label>
                        <div class="col-sm-9">
                            {!! Form::date('deposit_date', null, ['class' => 'form-control', 'id' => 'deposit_date']) !!}
                        </div>
                    </div>

                    <div class="form-group row"><label for="ref" class="col-sm-3 col-form-label">Description</label>
                        <div class="col-sm-9">
                            {!! Form::text('ref', null, ['class' => 'form-control', 'id' => 'ref']) !!}
                        </div>
                    </div>
                    <div class="form-group row"><label for="total_amount" class="col-sm-3 col-form-label">Amount</label>
                        <div class="col-sm-9">
                            {!! Form::number('total_amount', null, ['class' => 'form-control', 'id' => 'total_amount']) !!}
                        </div>
                    </div>
                    <div class="form-group row"><label for="coop_no" class="col-sm-3 col-form-label">&nbsp </label>
                        <div class="col-sm-9">
                            <button class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                    {!! Form::close() !!}
                </div>

            @endif
            </div>
        </div>
    </div>
</div>
@else
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="row align-items-center">
                <div class="col-md-8">
                
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card m-b-30">
            <div class="card-body">
            
                <p class="my-5">
                    This member does not exist
                </p>
            
            </div>
        </div>
    </div>
</div>
@endif

@endsection


@section('js')

@endsection

