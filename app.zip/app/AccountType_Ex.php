<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccountType_Ex extends Model
{
    protected $table = 'account_type__ext';
}
