<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IppisDeduction extends Model
{
    protected $dates = ['deduction_for'];
}
