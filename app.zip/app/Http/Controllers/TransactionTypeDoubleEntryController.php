<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TransactionTypeDoubleEntryController extends Controller
{
    //
}
