<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AccountTypeController extends Controller
{
    //
}
