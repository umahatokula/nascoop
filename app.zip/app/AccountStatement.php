<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccountStatement extends Model
{
    //
}
