<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PVNumber extends Model
{
    //
}
